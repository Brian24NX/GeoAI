# Gate 1 starter kit — travel speed project

This folder answers the first big question of the project:
**are the GPS hiking tracks on OpenStreetMap actually usable?**

## What's in here

| File | What it is |
|---|---|
| `gate1_audit.py` | The Gate 1 checker. Downloads GPS tracks for a region and tells you how many are usable. |
| `selftest.py` | Tests the checker on fake data. No internet needed. |
| `requirements.txt` | The 4 packages Gate 1 needs. |
| `environment.yml` | The full toolset for later (T1–T3). **Not needed yet.** |
| `reading_notes.md` | The week-1 papers in plain English. |
| `example_output/` | What the results look like. **All fake data** — just to show the format. |

---

## How to run it (about 15 minutes total)

**Step 1 — install (2 minutes)**

```
pip install -r requirements.txt
```

**Step 2 — make sure the code works (1 minute, no internet)**

```
python selftest.py
```

It should end with `ALL CHECKS PASSED`.

**Step 3 — run Gate 1 on a real region (5–15 minutes, needs internet)**

```
python gate1_audit.py --region white_mountains
```

Other choices: `cascades`, `front_range`, or `all` (runs all three and makes a
comparison table). Start with one region.

If it stops halfway, just run the same command again. Everything already
downloaded is saved in `cache/`, so it picks up where it left off and never
downloads the same thing twice.

---

## What the script does, in plain English

**1. Download.** It picks 4 small boxes over popular trails in the region and
asks OpenStreetMap for all the GPS points inside each box. OSM sends points in
pages of 5,000. Every page gets saved to disk.

**2. Sort the tracks.** When people upload GPS tracks to OSM, they choose a
privacy level:

- **identifiable** — points in time order, with the uploader's name → ✅ usable
- **trackable** — points in time order, anonymous → ✅ usable
- **public** — OSM shuffles the points (sorts them by location) → ❌ useless for speed

You can't compute speed from shuffled points, because you don't know which
point came after which.

**3. Compute speed.** For every pair of neighboring points:
speed = distance ÷ time.

> Worked example: two points 25 m apart, recorded 30 s apart →
> 25 ÷ 30 = 0.83 m/s → × 3.6 = **3.0 km/h**

**4. Remove stops.** Anything slower than 0.5 km/h counts as "stopped" (lunch,
photos, resting) and is thrown out. This is the crude rule from section 6 of the
plan — it's supposed to be tuned later.

**5. Report.** It prints a summary and saves results in `results/<region>/`:

- `summary.json` — the key numbers, plus every threshold used (your decisions log)
- `traces.csv` — one row per track
- `speed_histograms.png` — the plot to bring to your weekly meeting

---

## How to read the results

The most important number is this line:

```
Usable points: 48,210 of 85,000 (57%)   <- write this down (plan sec. 6)
```

The plan says this fraction goes in the paper, and nobody currently knows it.

Then check the three Gate 1 conditions from section 6 of the plan:

1. **Enough ordered tracks?** The plan doesn't give a number. Decide this with
   Danni and Tianyi.
2. **Median speed between 1.5 and 5 km/h?** That's normal walking. If yes, good sign.
3. **A second, faster bump in the histogram?** That's cyclists. Good sign if
   present — it means Question 4 (bikes vs. walkers) might be possible.

**In the right-hand plot**, if the gray (raw) and orange (filtered) lines sit
right on top of each other, the stop filter removed almost nothing. That
probably means it's missing real stops — see Lesson 1 below.

**Fail condition from the plan:** if almost everything comes back shuffled,
try a different region before building anything.

---

## Two things the fake-data test taught us

These both come from the same cause: **GPS points wobble.** Even standing
still, a phone's GPS position jumps around by a meter or two.

**Lesson 1: the 0.5 km/h stop filter misses stops.** A fake hiker stood still
for 20% of the hike. The filter caught only about 1%. The wobble makes a
standing person look like they're moving at 1–3 km/h. See
`example_output/stop_filter_problem.png`. Section 8 of the plan already says
to use "speed threshold plus minimum duration" — this shows why.

**Lesson 2: frequent GPS recording inflates speed.** The same fake 3.5 km/h
walker measured 9.6 km/h when GPS recorded every second, but 3.5 km/h when it
recorded every 30 seconds. See `example_output/speed_bias_vs_interval.png`.
This is part of why the plan measures speed over fixed-length trail segments
(25–50 m) instead of point to point.

⚠️ **Honest caveat:** the fake wobble is random at every point. Real GPS errors
drift slowly, so neighboring points are wrong in similar ways and partly cancel
out. The real effect is probably **smaller** than the fake one. The script's
"wobble check" line compares tracks recorded at different intervals on real
data, so you can see the true size.

---

## Known limitations (say these out loud if asked)

- The stop filter is crude (see Lesson 1).
- An anonymous track that gets split across two pages is counted twice.
- A hike that crosses two boxes is counted in both.
- "Walking-like" and "cycling-like" are just speed ranges. Real mode detection
  needs the trail's access tags from the map (plan section 8).
- The boxes are my picks of popular trail areas. Edit them in `REGIONS` at the
  top of `gate1_audit.py`.
- It reads up to 10 pages per box by default. Busy boxes may have more; the
  output says `hit page limit` when that happens. Use `--max-pages 30` to get more.

## Be polite to OpenStreetMap

OSM runs on volunteers' servers. The script waits 1 second between downloads,
identifies itself, and never downloads the same page twice. Don't remove the
wait, and don't delete `cache/` unless you really mean to re-download.
